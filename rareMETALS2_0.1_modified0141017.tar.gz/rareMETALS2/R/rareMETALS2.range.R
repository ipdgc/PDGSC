#' Meta-analysis of gene-level tests by range;
#'
#' @param score.stat.file files of score statistics
#' @param cov.file covariance matrix files
#' @param range tabix range for each gene/region
#' @param range.name The name of the range,e.g. gene names can be used
#' @param test rare variant tests to be used
#' @param maf.cutoff MAF cutoff used to analyze variants
#' @param alternative alternative hypothesis to be specified
#' @param ix.gold Gold standard population to align reference allele to
#' @param out.digits Number of digits used in the output
#' @param callrate.cutoff Cutoffs of call rate, lower than which will NOT be analyzed (labelled as missing)
#' @param hwe.cutoff Cutoffs of HWE p-values; Variants with HWE p-value smaller than the cutoffs are removed from subsequent analysis and labelled as missing;
#' @param hwe.ctrl.cutoff Cutoffs of HWE p-values using controls; Variants with HWE p-value smaller than the cutoffs are removed from subsequent analysis and labelled as missing; In case control studies, it is recommended to use hwe.ctrl.cutoff, since large effect variants may violate HWE. 
#' @param max.VT The maximum number of thresholds used in VT; Setting max.VT to 10 can improve the speed for calculation without affecting the power too much. The default parameter is NULL, which does not set upper limit on the number of variable frequency threhsold. 
#' @return a list consisting of results
#' @export
rareMETALS2.range <- function(ANNO,score.stat.file,cov.file,range,range.name,test='GRANVIL',maf.cutoff=1,alternative=c('two.sided','greater','less'),ix.gold=1,out.digits=4,callrate.cutoff=0,hwe.cutoff=0,hwe.ctrl.cutoff=0,max.VT=NULL) {
    res <- rareMETALS.range.core(ANNO,score.stat.file,cov.file,range[1],range.name[1],test,maf.cutoff,alternative,ix.gold,out.digits,callrate.cutoff,hwe.cutoff,hwe.ctrl.cutoff,max.VT);
    if(length(range)>1) {
        
        for(ii in 2:length(range)) {
            
            cat("Analyzing ",range.name[ii],"\n");
            res0 <- rareMETALS.range.core(ANNO,score.stat.file,cov.file,range[ii],range.name[ii],test,maf.cutoff,alternative,ix.gold,out.digits,callrate.cutoff,hwe.cutoff,hwe.ctrl.cutoff,max.VT)
            
            res$res.out <- rbind(res$res.out,res0$res.out);
            res$res.list <- c(res$res.list,res0$res.list);
            res$integratedData <- c(res$integratedData,res0$integratedData);
        }
    }
    return(res)
}
#' #' Meta-analysis of gene-level tests by range;
#'
#' @param score.stat.file files of score statistics
#' @param cov.file covariance matrix files
#' @param range tabix range for each gene/region
#' @param range.name The name of the range,e.g. gene names can be used
#' @param test rare variant tests to be used
#' @param maf.cutoff MAF cutoff used to analyze variants
#' @param alternative alternative hypothesis to be specified
#' @param ix.gold Gold standard population to align reference allele to
#' @param out.digits Number of digits used in the output
#' @param callrate.cutoff Cutoffs of call rate, lower than which will NOT be analyzed (labelled as missing)
#' @param hwe.cutoff Cutoffs of HWE p-values
#' @param max.VT The maximum number of thresholds used in VT; Setting max.VT to 10 can improve the speed for calculation without affecting the power too much. The default parameter is NULL, which does not set upper limit on the number of variable frequency threhsold. 
#' @return a list consisting of results
#' @export
rareMETALS.range.core <- function(ANNO,score.stat.file,cov.file,range,range.name,test='GRANVIL',maf.cutoff=1,alternative=c('two.sided','greater','less'),ix.gold=1,out.digits=4,callrate.cutoff=0,hwe.cutoff=0,hwe.ctrl.cutoff,max.VT=NULL) {
    alpha <- 0;
    no.boot <- 0;
    gene.name <- range.name;
    raw.data.all <- list();
    for(ii in 1:length(range)) {
        
        capture.output(raw.data.all[[ii]] <- rvmeta.readDataByRange( score.stat.file, cov.file, range[ii])[[1]]);
    }
    res.null <- list(gene.name=NA,
                     p.value=NA,
                     statistic=NA,
                     no.var=NA,
                     no.sample=NA,
                     anno=NA,
                     ref=NA,
                     alt=NA,
                     maf.cutoff=NA,
                     direction.burden.by.study=NA,
                     direction.meta.single.var=NA,
                     beta1.est=NA,
                     no.site=NA,
                     beta1.sd=NA,
                     hsq.est=NA,
                     pos=NA);
    if(length(raw.data.all)==0)
      {
        res <- list();
        for(ii in 1:length(range.name))
          {
            res.null$gene.name <- range.name[ii];
            res[[ii]] <- res.null;
          }
        
        return(res);        
      }
    res <- list(list(p.value=NA,statistic=NA,no.var=NA,no.sample=NA));
    
    p.value <- double(0);
    ref <- character(0);
    alt <- ref;
    direction.by.study <- character(0);
    statistic <- double(0);pos <- integer(0);anno <- character(0);direction <- integer(0);res.maf.vec <- double(0);beta1.est.vec <- double(0);beta1.sd.vec <- double(0);
    gene.name.out <- range.name;p.value.out <- rep(NA,length(range.name));statistic.out <- rep(NA,length(range.name));no.site.out <- rep(NA,length(range.name));beta1.est.out <- rep(NA,length(range.name));beta1.sd.out <- rep(NA,length(range.name));maf.cutoff.out <- rep(NA,length(range.name));direction.burden.by.study.out <- rep(NA,length(range.name));direction.meta.single.var.out <- rep(NA,length(range.name));pos.ref.alt.out <- rep(NA,length(range.name));top.singlevar.pval <- rep(NA,length(range.name));top.singlevar.refalt <- rep(NA,length(range.name));top.singlevar.pos <- rep(NA,length(range.name));top.singlevar.af <- rep(NA,length(range.name));integratedData <- list();
    for(kk in 1:length(raw.data.all))
      {
        raw.data <- raw.data.all[[kk]];
        raw.data.ori <- raw.data;
        raw.data$gene <- range.name[kk];
        QC.par <- list(callrate.cutoff=callrate.cutoff,
                       hwe.ctrl.cutoff=hwe.ctrl.cutoff,
                       hwe.cutoff=hwe.cutoff);
        raw.data <- QC(raw.data,QC.par,cov=1);        
        ix.var <- integer(0);
        if(ANNO=='gene')
          {
            if(length(raw.data$ustat[[1]])>0)
              ix.var <- 1:length(raw.data$ustat[[1]]);
          }
        if(ANNO!='gene')
          {
            if(length(raw.data$ustat[[1]])>0)
              {
                ix.var <- c(ix.var,grep(ANNO,raw.data$anno));
              }
          }
        ix.var <- sort(unique(ix.var));
        if(length(ix.var)==0)
          {
            res.null$gene.name <- gene.name[kk];
            res[[kk]] <- res.null;
          }
        if(length(ix.var)>=1) {
          ix.pop <- 1:length(raw.data$nSample);
          score.stat.vec.list <- list();mac.vec.list <- list();maf.vec.list <- list();cov.mat.list <- list();var.Y.list <- list();N.list <- list();mean.Y.list <- list();pos.list <- list();anno.list <- list();ac.vec.list <- list();af.vec.list <- list();ref.list <- list();alt.list <- list();vstat.list <- list();NCase.list <- list();NCtrl.list <- list();
          afCase.vec.list <- list();afCtrl.vec.list <- list();
          acCase.vec.list <- list();acCtrl.vec.list <- list();
          
          no.sample <- 0;no.case <- 0;no.ctrl <- 0;
          nref.list <- list();nalt.list <- list();nhet.list <- list();
          nrefCase.list <- list();naltCase.list <- list();nhetCase.list <- list();
          nrefCtrl.list <- list();naltCtrl.list <- list();nhetCtrl.list <- list();
          af.mat <- matrix(NA,ncol=length(ix.var),nrow=length(raw.data$ustat));
          ac.mat <- af.mat;
          afCase.mat <- af.mat;
          afCtrl.mat <- af.mat;
          acCase.mat <- af.mat;
          acCtrl.mat <- af.mat;
          N.mat <- af.mat;
          NCase.mat <- af.mat;NCtrl.mat <- af.mat;
          ##expandedCov <- FALSE;
          
          for(ii in 1:length(ix.pop))
            {
              N.list[[ii]] <- rm.na(as.integer(mean(raw.data$nSample[[ii]],na.rm=TRUE)));
              NCase.list[[ii]] <- rm.na(as.integer(mean(raw.data$nCase[[ii]],na.rm=TRUE)));
              NCtrl.list[[ii]] <- rm.na(as.integer(mean(raw.data$nCtrl[[ii]],na.rm=TRUE)));
              afCase.vec.list[[ii]] <- raw.data$afCase[[ii]];
              afCtrl.vec.list[[ii]] <- raw.data$afCtrl[[ii]];
              acCase.vec.list[[ii]] <- raw.data$acCase[[ii]];
              acCtrl.vec.list[[ii]] <- raw.data$acCtrl[[ii]];
              no.sample <- no.sample+N.list[[ii]];
              no.case <- no.case+NCase.list[[ii]];
              no.ctrl <- no.ctrl+NCtrl.list[[ii]];
              
              N.mat[ii,] <- raw.data$nSample[[ii]][ix.var];
              NCase.mat[ii,] <- raw.data$nCase[[ii]][ix.var];
              NCtrl.mat[ii,] <- raw.data$nCtrl[[ii]][ix.var];
              
              U.stat <- rm.na(raw.data$ustat[[ii]][ix.var]);
              V.stat <- rm.na(raw.data$vstat[[ii]][ix.var]);
              vstat.list[[ii]] <- V.stat;
              score.stat.vec.list[[ii]] <- rm.na(U.stat/V.stat);              
              ##raw.data$cov[[ii]] <- raw.data$covXX[[ii]][ix.var,ix.var]
              expandedCov <- FALSE;
              if(length(raw.data$covXZ[[ii]])>0) expandedCov <- TRUE;
              
              if(expandedCov==TRUE)
                  {
     
                      cov.mat.list[[ii]] <- matrix(raw.data$cov[[ii]][ix.var,ix.var],nrow=length(ix.var),ncol=length(ix.var));
                      covXZ.ii <- matrix(rm.na(raw.data$covXZ[[ii]])[ix.var,],nrow=length(ix.var),ncol=ncol(raw.data$covXZ[[ii]]));
                      covZZ.ii <- matrix(rm.na(raw.data$covZZ[[ii]]),nrow=nrow(raw.data$covZZ[[ii]]),ncol=ncol(raw.data$covZZ[[ii]]));
                      covXX.ii <- rm.na(cov.mat.list[[ii]]+(covXZ.ii)%*%(ginv(covZZ.ii))%*%t(covXZ.ii));
                  }
              if(expandedCov==FALSE)
                  {
                      cov.mat.list[[ii]] <- as.matrix(rm.na(as.matrix(raw.data$cov[[ii]])[ix.var,ix.var]));
                  }
              
              var.Y.list[[ii]] <- 1;
              mean.Y.list[[ii]] <- 0;
              af.vec.list[[ii]] <- rm.na((raw.data$af[[ii]]));
              ac.vec.list[[ii]] <- rm.na((raw.data$ac[[ii]]));
              af.mat[ii,] <- af.vec.list[[ii]][ix.var];
              afCase.mat[ii,] <- afCase.vec.list[[ii]][ix.var];
              afCtrl.mat[ii,] <- afCtrl.vec.list[[ii]][ix.var];
              
              ac.mat[ii,] <- ac.vec.list[[ii]][ix.var];
              acCase.mat[ii,] <- acCase.vec.list[[ii]][ix.var];
              acCtrl.mat[ii,] <- acCtrl.vec.list[[ii]][ix.var];
              
              pos.list[[ii]] <- (raw.data$pos)[ix.var];
              ref.list[[ii]] <- (raw.data$ref)[[ii]][ix.var];
              alt.list[[ii]] <- (raw.data$alt)[[ii]][ix.var];
              anno.list[[ii]] <- (raw.data$anno)[ix.var];
              nref.list[[ii]] <- rm.na((raw.data$nref)[[ii]])[ix.var];
              nalt.list[[ii]] <- rm.na((raw.data$nalt)[[ii]])[ix.var];
              nhet.list[[ii]] <- rm.na((raw.data$nhet)[[ii]])[ix.var];
              nrefCase.list[[ii]] <- rm.na((raw.data$nrefCase)[[ii]])[ix.var];
              naltCase.list[[ii]] <- rm.na((raw.data$naltCase)[[ii]])[ix.var];
              nhetCase.list[[ii]] <- rm.na((raw.data$nhetCase)[[ii]])[ix.var];
              nrefCtrl.list[[ii]] <- rm.na((raw.data$nrefCtrl)[[ii]])[ix.var];
              naltCtrl.list[[ii]] <- rm.na((raw.data$naltCtrl)[[ii]])[ix.var];
              nhetCtrl.list[[ii]] <- rm.na((raw.data$nhetCtrl)[[ii]])[ix.var];
          }
          if(length(ix.pop)>1)
            {
              for(ii in 1:length(ix.var))
                {
                  for(jj in (1:length(ix.pop))[-ix.gold])
                    {
                      if(is.na(ref.list[[ix.gold]][ii]) & !is.na(ref.list[[jj]][ii]))
                        {
                          ref.list[[ix.gold]][ii] <- ref.list[[jj]][ii];
                          alt.list[[ix.gold]][ii] <- alt.list[[jj]][ii];
                        }
                      if((is.na(alt.list[[ix.gold]][ii]) | (alt.list[[ix.gold]][ii])=='0' | (alt.list[[ix.gold]][ii])==".") & (!is.na(alt.list[[jj]][ii]) & (alt.list[[jj]][ii]!="0") & (alt.list[[jj]][ii]!=".")))
                        {
                          alt.list[[ix.gold]][ii] <- alt.list[[jj]][ii];
                        }
                      if(!is.na(ref.list[[jj]][ii]) & !is.na(ref.list[[ix.gold]][ii]))
                        {
                          if(ref.list[[jj]][ii]==alt.list[[ix.gold]][ii] & (ref.list[[jj]][ii])!=(ref.list[[ix.gold]][ii]))
                            {
                                tmp <- ref.list[[jj]][ii];
                                ref.list[[jj]][ii] <- alt.list[[jj]][ii];
                                alt.list[[jj]][ii] <- tmp;                              
                                score.stat.vec.list[[jj]][ii] <- (-1)*(score.stat.vec.list[[jj]][ii]);
                                cov.mat.list[[jj]][ii,] <- (-1)*(cov.mat.list[[jj]][ii,]);
                                cov.mat.list[[jj]][,ii] <- (-1)*(cov.mat.list[[jj]][,ii]);
                                af.vec.list[[jj]][ii] <- 1-af.vec.list[[jj]][ii];
                                ac.vec.list[[jj]][ii] <- 2*N.mat[jj,ii]-ac.vec.list[[jj]][ii];
                                afCase.vec.list[[jj]][ii] <- 1-afCase.vec.list[[jj]][ii];
                                acCase.vec.list[[jj]][ii] <- 2*NCase.mat[jj,ii]-acCase.vec.list[[jj]][ii];
                                afCtrl.vec.list[[jj]][ii] <- 1-afCtrl.vec.list[[jj]][ii];
                                acCtrl.vec.list[[jj]][ii] <- 2*NCtrl.mat[jj,ii]-acCtrl.vec.list[[jj]][ii];
                                af.mat[jj,ii] <- af.vec.list[[jj]][ii];
                                ac.mat[jj,ii] <- ac.vec.list[[jj]][ii];
                                afCase.mat[jj,ii] <- afCase.vec.list[[jj]][ii];
                                acCase.mat[jj,ii] <- acCase.vec.list[[jj]][ii];
                                afCtrl.mat[jj,ii] <- afCtrl.vec.list[[jj]][ii];
                                acCtrl.mat[jj,ii] <- acCtrl.vec.list[[jj]][ii];
                                tmp <- nref.list[[jj]][ii];
                                nref.list[[jj]][ii] <- nalt.list[[jj]][ii];
                                nalt.list[[jj]][ii] <- tmp;

                                tmp <- nrefCase.list[[jj]][ii];
                                nrefCase.list[[jj]][ii] <- naltCase.list[[jj]][ii];
                                naltCase.list[[jj]][ii] <- tmp;

                                tmp <- nrefCtrl.list[[jj]][ii];
                                nrefCtrl.list[[jj]][ii] <- naltCtrl.list[[jj]][ii];
                                naltCtrl.list[[jj]][ii] <- tmp;
                            }
                      }
                  }
              }
          }          
          af.vec <- colSums(af.mat*N.mat,na.rm=TRUE)/colSums(N.mat,na.rm=TRUE);
          ac.vec <- colSums(ac.mat,na.rm=TRUE);
          afCase.vec <- colSums(afCase.mat*NCase.mat,na.rm=TRUE)/colSums(NCase.mat,na.rm=TRUE);
          acCase.vec <- colSums(acCase.mat,na.rm=TRUE);
          afCtrl.vec <- colSums(afCtrl.mat*NCtrl.mat,na.rm=TRUE)/colSums(NCtrl.mat,na.rm=TRUE);
          acCtrl.vec <- colSums(acCtrl.mat,na.rm=TRUE);

          maf.vec <- af.vec;
          mac.vec <- ac.vec;          
          
          ix.major <- which(af.vec>0.5);
          if(length(ix.major)>0)
            {
              maf.vec[ix.major] <- 1-maf.vec[ix.major];
              mac.vec[ix.major] <- 2*no.sample-ac.vec[ix.major];
              tmp.major <- flip.score.cov(score.stat.vec.list,cov.mat.list,ix.major);
              score.stat.vec.list <- tmp.major$score.stat.vec.list;
              cov.mat.list <- tmp.major$cov.mat.list;
            }
          ix.rare <- which(maf.vec<maf.cutoff & maf.vec>0);          
          maf.vec.rare <- maf.vec[ix.rare];
          mac.vec.rare <- mac.vec[ix.rare];
          
          if(length(ix.rare)==0)
            {
              res.null$gene.name <- gene.name[kk];
              res[[kk]] <- res.null;
            }
          if(length(ix.rare)>=1)
            {
                af.vec <- af.vec[ix.rare];
                ac.vec <- ac.vec[ix.rare];
                afCase.vec <- afCase.vec[ix.rare];
                afCtrl.vec <- afCtrl.vec[ix.rare];
                acCase.vec <- acCase.vec[ix.rare];
                acCtrl.vec <- acCtrl.vec[ix.rare];
                nCase.out <- colSums(NCase.mat)[ix.rare];
                nCtrl.out <- colSums(NCtrl.mat)[ix.rare];
                
              for(ii in 1:length(ix.pop))
                {
                  score.stat.vec.list[[ii]] <- score.stat.vec.list[[ii]][ix.rare];
                  vstat.list[[ii]] <- vstat.list[[ii]][ix.rare];
                  cov.mat.list[[ii]] <- as.matrix(cov.mat.list[[ii]][ix.rare,ix.rare]);
                  af.vec.list[[ii]] <- af.vec.list[[ii]][ix.var][ix.rare];
                  ac.vec.list[[ii]] <- ac.vec.list[[ii]][ix.var][ix.rare];
                  afCase.vec.list[[ii]] <- afCase.vec.list[[ii]][ix.var][ix.rare];
                  afCtrl.vec.list[[ii]] <- afCtrl.vec.list[[ii]][ix.var][ix.rare];
                  acCase.vec.list[[ii]] <- acCase.vec.list[[ii]][ix.var][ix.rare];
                  acCtrl.vec.list[[ii]] <- acCtrl.vec.list[[ii]][ix.var][ix.rare];
                  nref.list[[ii]] <- nref.list[[ii]][ix.rare];
                  nalt.list[[ii]] <- nalt.list[[ii]][ix.rare];
                  nhet.list[[ii]] <- nhet.list[[ii]][ix.rare];

                  nrefCase.list[[ii]] <- nrefCase.list[[ii]][ix.rare];
                  naltCase.list[[ii]] <- naltCase.list[[ii]][ix.rare];
                  nhetCase.list[[ii]] <- nhetCase.list[[ii]][ix.rare];

                  nrefCtrl.list[[ii]] <- nrefCtrl.list[[ii]][ix.rare];
                  naltCtrl.list[[ii]] <- naltCtrl.list[[ii]][ix.rare];
                  nhetCtrl.list[[ii]] <- nhetCtrl.list[[ii]][ix.rare];

                  anno.list[[ii]] <- anno.list[[ix.gold]][ix.rare];
                  pos.list[[ii]] <- pos.list[[ix.gold]][ix.rare];
                  ref.list[[ii]] <- ref.list[[ix.gold]][ix.rare];
                  alt.list[[ii]] <- alt.list[[ix.gold]][ix.rare];
                }
              N.mat <- matrix(N.mat[,ix.rare],nrow=nrow(N.mat),ncol=length(ix.rare));
              res.extra <- list(anno=anno.list[[ix.gold]],
                                pos=pos.list[[ix.gold]],
                                ref=ref.list[[ix.gold]],
                                alt=alt.list[[ix.gold]],
                                af.vec.list=af.vec.list,
                                afCase.vec.list=afCase.vec.list,
                                afCtrl.vec.list=afCtrl.vec.list,
                                acCase.vec.list=acCase.vec.list,
                                acCtrl.vec.list=acCtrl.vec.list,
                                nref.list=nref.list,
                                nalt.list=nalt.list,
                                nhet.list=nhet.list,
                                nrefCase.list=nrefCase.list,
                                nhetCase.list=nhetCase.list,
                                naltCase.list=naltCase.list,
                                nrefCtrl.list=nrefCtrl.list,
                                naltCtrl.list=naltCtrl.list,
                                nhetCtrl.list=nhetCtrl.list,
                                score.stat.vec.list=score.stat.vec.list,
                                cov.mat.list=cov.mat.list,
                                pos.list=pos.list,
                                alt.list=alt.list,
                                ref.list=ref.list,
                                raw.data=raw.data.ori,
                                gene.name=gene.name[kk]);
              if(test=='WSS')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='WSS',extra.pars=list(vstat.list=vstat.list,weight='MB',ac.vec.list=ac.vec.list,
                                                                                                                                                    maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
              if(test=='GRANVIL')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='WSS',extra.pars=list(vstat.list=vstat.list,weight='MZ',ac.vec.list=ac.vec.list,
                                                                                                                                                    maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
              if(test=='SKAT_linearkernel')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='SKAT',extra.pars=list(vstat.list=vstat.list,kernel='linear',ac.vec.list=ac.vec.list,
                                                                                                                                                     maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
				if(test=='SKAT_betakernel')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='SKAT',extra.pars=list(vstat.list=vstat.list,kernel='beta',ac.vec.list=ac.vec.list,
                                                                                                                                                     maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
              if(test=='SKAT-O_betakernel')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='SKAT',extra.pars=list(vstat.list=vstat.list,kernel='optimal-beta',ac.vec.list=ac.vec.list,
                                                                                                                                                     maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
              if(test=='SKAT-O_linearkernel')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='SKAT',extra.pars=list(vstat.list=vstat.list,kernel='optimal-linear',ac.vec.list=ac.vec.list,
                                                                                                                                                     maf.vec=maf.vec.rare,mac.vec=mac.vec.rare))));
                  res[[kk]] <- c(res.kk,res.extra);
                  res[[kk]]$maf.cutoff <- maf.cutoff;
                }
              if(test=='VT')
                {
                  res.kk <- (c(rvmeta.CMH(score.stat.vec.list,af.vec.list,cov.mat.list,var.Y.list,N.mat,alternative,no.boot,alpha,rv.test='VT',extra.pars=list(vstat.list=vstat.list,ac.vec.list=ac.vec.list,maf.vec=maf.vec.rare,mac.vec=mac.vec.rare,max.TH=max.VT))));
                 
                  res[[kk]] <- c(res.kk,res.extra);
                }
              gene.name.out[kk] <- res[[kk]]$gene.name;
              p.value.out[kk] <- res[[kk]]$p.value;
              statistic.out[kk] <- res[[kk]]$statistic;
              no.site.out[kk] <- res[[kk]]$no.site;
              beta1.est.out[kk] <- res[[kk]]$beta1.est;
              beta1.sd.out[kk] <- res[[kk]]$beta1.sd;
              maf.cutoff.out[kk] <- res[[kk]]$maf.cutoff;
              direction.burden.by.study.out[kk] <- res[[kk]]$direction.burden.by.study;
              direction.meta.single.var.out[kk] <- res[[kk]]$direction.meta.single.var;          
              pos.ref.alt.out[kk] <- paste(res[[kk]]$pos,res[[kk]]$ref,res[[kk]]$alt,sep='/',collapse=',');
              ix.best <- res[[kk]]$ix.best;
              
              top.singlevar.pos[kk] <- res[[kk]]$pos[ix.best];
              top.singlevar.refalt[kk] <- paste(c(res[[kk]]$ref[ix.best],res[[kk]]$alt[ix.best]),sep="/",collapse="/");
              top.singlevar.pval[kk] <- res[[kk]]$singlevar.pval.vec[ix.best];
              top.singlevar.af[kk] <- res[[kk]]$singlevar.af.vec[ix.best];
              
              ref.out <- list(res[[kk]]$ref);
              alt.out <- list(res[[kk]]$alt);
              nSample.out <- list(rep(res[[kk]]$nSample,length(ref.out[[1]])));
              af.out <- list(res[[kk]]$singlevar.af.vec);
              ac.out <- list(as.integer(af.out[[1]]*nSample.out[[1]]*2));
              callrate <- list(rep(1,length(ref.out[[1]])));
              nref.out <- 0;nrefCase.out <- 0;nrefCtrl.out <- 0;
              nalt.out <- 0;naltCase.out <- 0;naltCtrl.out <- 0;
              nhet.out <- 0;nhetCase.out <- 0;nhetCtrl.out <- 0;
              ustat.out <- list(res[[kk]]$ustat);
              vstat.out <- list(res[[kk]]$vstat);
              callrate.out <- list(rep(1,length(ref.out[[1]])));
              hwe.out <- list(rep(1,length(ref.out[[1]])));
              effect.out <- list(ustat.out[[1]]/vstat.out[[1]]^2);
              pVal.out <- list(res[[kk]]$singlevar.pval.vec);
              cov.out <- list(res[[kk]]$cov);
              pos.out <- res[[kk]]$pos;
              anno.out <- res[[kk]]$anno;
              for(aa in 1:length(nref.list))
                {
                  nref.out <- nref.out+nref.list[[aa]];
                  nalt.out <- nalt.out+nalt.list[[aa]];
                  nhet.out <- nhet.out+nhet.list[[aa]];
                  nrefCase.out <- nrefCase.out+nrefCase.list[[aa]];
                  naltCase.out <- naltCase.out+naltCase.list[[aa]];
                  nhetCase.out <- nhetCase.out+nhetCase.list[[aa]];
                  nrefCtrl.out <- nrefCtrl.out+nrefCtrl.list[[aa]];
                  naltCtrl.out <- naltCtrl.out+naltCtrl.list[[aa]];
                  nhetCtrl.out <- nhetCtrl.out+nhetCtrl.list[[aa]];

                }
                nref.out <- list(nref.out);
                nalt.out <- list(nalt.out);
                nhet.out <- list(nhet.out);
                nrefCase.out <- list(nrefCase.out);
                naltCase.out <- list(naltCase.out);
                nhetCase.out <- list(nhetCase.out);
                nrefCtrl.out <- list(nrefCtrl.out);
                naltCtrl.out <- list(naltCtrl.out);
                nhetCtrl.out <- list(nhetCtrl.out);
                nCase.out <- list(nCase.out);
                nCtrl.out <- list(nCtrl.out);
                
                
                
                integratedData[[kk]] <- list(ref=ref.out,
                                             alt=alt.out,
                                             nSample=nSample.out,
                                             af=af.out,
                                             ac=ac.out,
                                           callrate=callrate.out,
                                           hwe=hwe.out,
                                           nref=nref.out,
                                           nalt=nalt.out,
                                           ustat=ustat.out,
                                           vstat=vstat.out,
                                           nhet=nhet.out,
                                           nrefCase=nrefCase.out,
                                           naltCase=naltCase.out,
                                           nhetCase=nhetCase.out,
                                           nrefCtrl=nrefCtrl.out,
                                           naltCtrl=naltCtrl.out,
                                           nhetCtrl=nhetCtrl.out,
                                           effect=effect.out,
                                           pVal=pVal.out,
                                           cov=cov.out,
                                           pos=pos.out,
                                           covZZ=list(matrix(nrow=0,ncol=0)),
                                           covXZ=list(matrix(ncol=0,nrow=length(ref.out[[1]]))),
                                           hweCase=list(rep(NA,length(ref.out[[1]]))),
                                           hweCtrl=list(rep(NA,length(ref.out[[1]]))),
                                           afCtrl=list(rep(NA,length(ref.out[[1]]))),
                                           afCase=list(rep(NA,length(ref.out[[1]]))),
                                           
                                           anno=anno.out);
            }
        }
    }
    res.out <- cbind(gene.name.out,p.value.out,statistic.out,no.site.out,beta1.est.out,beta1.sd.out,maf.cutoff.out,direction.burden.by.study.out,direction.meta.single.var.out,top.singlevar.pos,top.singlevar.refalt,top.singlevar.pval,top.singlevar.af,pos.ref.alt.out);   
    return(list(res.list=res,
                integratedData=integratedData,
                res.out=res.out));
  }

r2cov.mat <- function(r2.mat,maf.vec)
  {
    var.vec <- sqrt(maf.vec*(1-maf.vec)*2);
    var.mat <- (var.vec%*%t(var.vec));
    cov.mat <- r2.mat*var.mat;
    return(cov.mat);
  }
flip.score.cov <- function(score.stat.vec.list,cov.mat.list,ix.major)
  {
    for(ii in 1:length(score.stat.vec.list))
      {
        score.stat.vec.list[[ii]][ix.major] <- (-1)*score.stat.vec.list[[ii]][ix.major];
        cov.mat.list[[ii]][ix.major,] <- (-1)*cov.mat.list[[ii]][ix.major,];
        cov.mat.list[[ii]][,ix.major] <- (-1)*cov.mat.list[[ii]][,ix.major];
      }
    return(list(cov.mat.list=cov.mat.list,
                score.stat.vec.list=score.stat.vec.list));
  }
check.mono <- function(af.vec.list,ac.vec.list,N.list)
  {
    count <- rep(0,length(af.vec.list[[1]]));
    for(ii in 1:length(af.vec.list))
      {
        count <- count+(af.vec.list[[ii]]==1 | af.vec.list[[ii]]==0);
      }
    ix.change <- which(count==length(af.vec.list));
    if(length(ix.change)>0)
      {
        for(ii in 1:length(af.vec.list))
          {
            af.vec.list[[ii]][ix.change] <- 0;
            ac.vec.list[[ii]][ix.change] <- N.list[[ii]]
          }
      }
    return(list(af.vec.list=af.vec.list,
                ac.vec.list=ac.vec.list));
  }
