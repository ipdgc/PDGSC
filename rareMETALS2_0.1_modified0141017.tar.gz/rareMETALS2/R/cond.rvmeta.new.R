#' Conditional meta-analyses of rare variants using extended covariance matrix;
#'
#' @param ustat.list The list consisting of ustat from each study;
#' @param vstat.list The list consisting of vstat from each study;
#' @param cov.mat.list The list for centered covariance matrices;
#' @param covXX.list The list consisting of X^T%W%X;  
#' @param covXZ.list The list consisting of X^T%*%Z;
#' @param covZZ.list The list consisting of Z^T%*%Z;
#' @param beta.list The list of estimated genetic effects;
#' @param ix.X1 The index for canddiate variant;
#' @param ix.X2 The index for known variant;
#' @export
cond.rvmeta.core.new <- function(ustat.list,vstat.list,cov.mat.list,covXX.list,covXZ.list,covZZ.list,beta.list,ix.X1,ix.X2) {
    ustat.cond.all <- 0;
    ustat.cond.2nd.all <- 0;
    vstat.cond.all <- 0;
    direction.single.vec <- 0;
    V.cond.all <- 0;
    ustat.cond.list <- list();
    ustat.cond.2nd.list <- list();
    vstat.cond.list <- list();
    V.cond.list <- list();
    for(ii in 1:length(ustat.list)) {
        cov.mat.list[[ii]] <- (cov.mat.list[[ii]])
        ########print("cov.mat.list");
        ########print(cov.mat.list[[ii]]);
        ustat.Can <- ustat.list[[ii]][ix.X1];
        ustat.Knw <- ustat.list[[ii]][ix.X2];
        vstat.Can <- vstat.list[[ii]][ix.X1];
        vstat.Knw <- vstat.list[[ii]][ix.X2];
        cov.CanCan <- matrix(covXX.list[[ii]][ix.X1,ix.X1],nrow=length(ix.X1),ncol=length(ix.X1));
        cov.KCKC <- rbind(cbind(matrix(covXX.list[[ii]][ix.X2,ix.X2],nrow=length(ix.X2),ncol=length(ix.X2)),
                                  matrix(covXZ.list[[ii]][ix.X2,],nrow=length(ix.X2),ncol=ncol(covZZ.list[[ii]]))),
                            cbind(t(matrix(covXZ.list[[ii]][ix.X2,],nrow=length(ix.X2),ncol=ncol(covZZ.list[[ii]]))),
                                  (covZZ.list[[ii]])));
        cov.KnwKnw <- matrix(covXX.list[[ii]][ix.X2,ix.X2],nrow=length(ix.X2),ncol=length(ix.X2));
        cov.CanKC <- cbind(matrix(covXX.list[[ii]][ix.X1,ix.X2],nrow=length(ix.X1),ncol=length(ix.X2)),
                           matrix(covXZ.list[[ii]][ix.X1,],nrow=length(ix.X1),ncol=ncol(covXZ.list[[ii]])));
        cov.KnwCovar <- matrix(covXZ.list[[ii]][ix.X2,],nrow=length(ix.X2),ncol=ncol(covXZ.list[[ii]]));
        cov.CovarCovar <- covZZ.list[[ii]];
        cov.CanKnw <- cov.mat.list[[ii]][ix.X1,ix.X2];
        V.Knw <- cov.KnwKnw-cov.KnwCovar%*%ginv(cov.CovarCovar)%*%t(cov.KnwCovar)
        beta.Knw <- ginv(V.Knw)%*%(beta.list[[ii]][ix.X2]*(vstat.list[[ii]][ix.X2])^2)
        ########print(c("beta.Knw",beta.Knw,beta.list[[ii]][ix.X2]));
        ustat.cond <- ustat.Can-cov.CanKnw%*%beta.Knw;
        V.cond <- matrix(cov.CanCan-(cov.CanKC)%*%ginv(cov.KCKC)%*%t(cov.CanKC),nrow=nrow(cov.CanCan),ncol=ncol(cov.CanCan));
        ustat.cond.list[[ii]] <- ustat.cond;
        V.cond.list[[ii]] <- V.cond;
        ## f.case <- fCase.list[[ii]];
        ## af <- af.list[[ii]];
        vstat.cond.list[[ii]] <- sqrt(diag(V.cond.list[[ii]]));
        ########print(c('beta.Knw',beta.Knw));
        ########print("cov.CanKnw");
        ########print(cov.CanKnw);

        ustat.cond.all <- ustat.cond.all+ustat.cond.list[[ii]];
        vstat.cond.all <- vstat.cond.all+vstat.cond.list[[ii]];
        V.cond.all <- V.cond.all+V.cond.list[[ii]];
        ########print(c('ustat,vstat',ustat.cond.list[[ii]],vstat.cond.list[[ii]]));
    }
        return(list(ustat.cond.list=ustat.cond.list,
                    vstat.cond.list=vstat.cond.list,
                    ustat.cond.all=ustat.cond.all,
                    vstat.cond.all=vstat.cond.all,
                    V.cond.all=V.cond.all));
}

#' Conditional meta-analyses of rare variants using extended covariance matrix;
#'
#' @param ustat.list The list consisting of ustat from each study;
#' @param vstat.list The list consisting of vstat from each study;
#' @param cov.mat.list The list for centered covariance matrices;
#' @param covXX.list The list consisting of X^T%W%X;  
#' @param covXZ.list The list consisting of X^T%*%Z;
#' @param covZZ.list The list consisting of Z^T%*%Z;
#' @param beta.list The list of genetic effect estimates;
#' @param ix.X1 The index for canddiate variant;
#' @param ix.X2 The index for known variant;
#' @export
cond.rvmeta.single.new <- function(ustat.list,vstat.list,cov.mat.list,covXX.list,covXZ.list,covZZ.list,beta.list,ix.X1,ix.X2) {
    res <- cond.rvmeta.core.new(ustat.list,vstat.list,cov.mat.list,covXX.list,covXZ.list,covZZ.list,beta.list,ix.X1,ix.X2);
    statistic.single <- (res$ustat.cond.all/res$vstat.cond.all)^2;
    p.value.single <- pchisq(statistic.single,lower.tail=FALSE,df=1);
    beta1.est.single <- res$ustat.cond.all/(res$vstat.cond.all)^2;
    beta1.sd.single <- 1/(res$vstat.cond.all)^2;

    direction.vec <- 0;
    for(ii in 1:length(res$ustat.cond.list)){
        if(is.na(res$ustat.cond.list[[ii]][1])) {
            direction.vec[ii] <- "X";
        }
        if(!is.na(res$ustat.cond.list[[ii]][1])) {
            if(res$ustat.cond.list[[ii]][1]==0) direction.vec[ii] <- "=";
            if(res$ustat.cond.list[[ii]][1]>0) direction.vec[ii] <- "+";
            if(res$ustat.cond.list[[ii]][1]<0) direction.vec[ii] <- "-";
        }
    }
    
    return(list(p.value.single=p.value.single,
                statistic.single=statistic.single,
                beta1.est.single=beta1.est.single,
                direction.single.vec=paste(direction.vec,sep="",collapse=""),
                beta1.sd.single=beta1.sd.single));
}
